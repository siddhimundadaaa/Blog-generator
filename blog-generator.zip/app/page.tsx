"use client"

import { useState } from "react"
import { Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BlogGeneratorForm } from "@/components/blog-generator-form"
import { BlogPreview } from "@/components/blog-preview"
import { BlogEditor } from "@/components/blog-editor"

export default function Home() {
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedBlog, setGeneratedBlog] = useState<{
    title: string
    content: string
    coverImagePrompt: string
  } | null>(null)
  const [activeTab, setActiveTab] = useState("generate")

  const handleGenerate = async (formData: {
    topic: string
    tone: string
    length: string
    keywords: string
  }) => {
    setIsGenerating(true)

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (!response.ok) {
        throw new Error("Failed to generate blog")
      }

      const data = await response.json()
      setGeneratedBlog(data)
      setActiveTab("preview")
    } catch (error) {
      console.error("Error generating blog:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <main className="container mx-auto py-10 px-4 max-w-5xl">
      <h1 className="text-4xl font-bold text-center mb-2">AI Blog Generator</h1>
      <p className="text-muted-foreground text-center mb-8">
        Create professional blog posts in seconds with the power of AI
      </p>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="generate">Generate</TabsTrigger>
          <TabsTrigger value="preview" disabled={!generatedBlog}>
            Preview
          </TabsTrigger>
          <TabsTrigger value="edit" disabled={!generatedBlog}>
            Edit
          </TabsTrigger>
        </TabsList>

        <TabsContent value="generate">
          <Card>
            <CardContent className="pt-6">
              <BlogGeneratorForm onGenerate={handleGenerate} isGenerating={isGenerating} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preview">
          {generatedBlog && (
            <BlogPreview
              title={generatedBlog.title}
              content={generatedBlog.content}
              coverImagePrompt={generatedBlog.coverImagePrompt}
            />
          )}
          <div className="flex justify-end mt-4 gap-2">
            <Button variant="outline" onClick={() => setActiveTab("generate")}>
              Back
            </Button>
            <Button onClick={() => setActiveTab("edit")}>Edit Content</Button>
          </div>
        </TabsContent>

        <TabsContent value="edit">
          {generatedBlog && (
            <BlogEditor
              initialTitle={generatedBlog.title}
              initialContent={generatedBlog.content}
              coverImagePrompt={generatedBlog.coverImagePrompt}
            />
          )}
        </TabsContent>
      </Tabs>

      {isGenerating && (
        <div className="fixed inset-0 bg-background/80 flex items-center justify-center z-50">
          <div className="flex flex-col items-center gap-2">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-lg font-medium">Generating your blog post...</p>
          </div>
        </div>
      )}
    </main>
  )
}
