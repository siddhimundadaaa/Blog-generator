"use client"

import { useState } from "react"
import { Save } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

type BlogEditorProps = {
  initialTitle: string
  initialContent: string
  coverImagePrompt: string
}

export function BlogEditor({ initialTitle, initialContent, coverImagePrompt }: BlogEditorProps) {
  const [title, setTitle] = useState(initialTitle)
  const [content, setContent] = useState(initialContent)
  const [isSaving, setIsSaving] = useState(false)

  const handleSave = async () => {
    setIsSaving(true)

    try {
      // Here you would typically save to a database
      // For now, we'll just simulate a delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Create a downloadable file
      const blogData = {
        title,
        content,
        date: new Date().toISOString(),
      }

      const blob = new Blob([JSON.stringify(blogData, null, 2)], { type: "application/json" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `${title.toLowerCase().replace(/\s+/g, "-")}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      // You could also export as markdown or HTML
      const markdownContent = `# ${title}\n\n${content}`
      const markdownBlob = new Blob([markdownContent], { type: "text/markdown" })
      const markdownUrl = URL.createObjectURL(markdownBlob)
      const markdownLink = document.createElement("a")
      markdownLink.href = markdownUrl
      markdownLink.download = `${title.toLowerCase().replace(/\s+/g, "-")}.md`
      document.body.appendChild(markdownLink)
      markdownLink.click()
      document.body.removeChild(markdownLink)
      URL.revokeObjectURL(markdownUrl)
    } catch (error) {
      console.error("Error saving blog:", error)
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-4">
          <div>
            <label htmlFor="title" className="block text-sm font-medium mb-1">
              Blog Title
            </label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} className="text-xl font-bold" />
          </div>

          <div>
            <label htmlFor="content" className="block text-sm font-medium mb-1">
              Blog Content
            </label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="min-h-[500px] font-serif"
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => window.print()}>
              Print
            </Button>
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? (
                <>
                  <Save className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save & Export
                </>
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
