"use client"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const formSchema = z.object({
  topic: z.string().min(3, {
    message: "Topic must be at least 3 characters.",
  }),
  tone: z.string({
    required_error: "Please select a tone.",
  }),
  length: z.string({
    required_error: "Please select a length.",
  }),
  keywords: z.string().optional(),
})

type BlogGeneratorFormProps = {
  onGenerate: (values: z.infer<typeof formSchema>) => void
  isGenerating: boolean
}

export function BlogGeneratorForm({ onGenerate, isGenerating }: BlogGeneratorFormProps) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      topic: "",
      tone: "professional",
      length: "medium",
      keywords: "",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    onGenerate(values)
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="topic"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Blog Topic</FormLabel>
              <FormControl>
                <Input placeholder="E.g., The Future of AI in Healthcare" {...field} />
              </FormControl>
              <FormDescription>Enter the main topic or title for your blog post.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="tone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tone</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a tone" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="professional">Professional</SelectItem>
                    <SelectItem value="casual">Casual</SelectItem>
                    <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                    <SelectItem value="informative">Informative</SelectItem>
                    <SelectItem value="humorous">Humorous</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>Select the writing style for your blog.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="length"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Length</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select length" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="short">Short (~300 words)</SelectItem>
                    <SelectItem value="medium">Medium (~600 words)</SelectItem>
                    <SelectItem value="long">Long (~1000 words)</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>Choose how long your blog post should be.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="keywords"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Keywords (Optional)</FormLabel>
              <FormControl>
                <Textarea placeholder="E.g., artificial intelligence, healthcare, technology, innovation" {...field} />
              </FormControl>
              <FormDescription>Enter keywords to include in your blog post, separated by commas.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full" disabled={isGenerating}>
          {isGenerating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating...
            </>
          ) : (
            "Generate Blog Post"
          )}
        </Button>
      </form>
    </Form>
  )
}
