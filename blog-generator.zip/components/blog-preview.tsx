"use client"

import { useState, useEffect } from "react"
import { Loader2 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

type BlogPreviewProps = {
  title: string
  content: string
  coverImagePrompt: string
}

export function BlogPreview({ title, content, coverImagePrompt }: BlogPreviewProps) {
  const [coverImage, setCoverImage] = useState<string | null>(null)
  const [isLoadingImage, setIsLoadingImage] = useState(true)

  useEffect(() => {
    const generateCoverImage = async () => {
      try {
        setIsLoadingImage(true)
        const response = await fetch("/api/generate-image", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ prompt: coverImagePrompt }),
        })

        if (!response.ok) {
          throw new Error("Failed to generate image")
        }

        const data = await response.json()
        setCoverImage(data.imageUrl)
      } catch (error) {
        console.error("Error generating cover image:", error)
        // Use a placeholder if image generation fails
        setCoverImage("/placeholder.svg?height=400&width=800")
      } finally {
        setIsLoadingImage(false)
      }
    }

    generateCoverImage()
  }, [coverImagePrompt])

  // Format the content with proper paragraphs
  const formattedContent = content.split("\n\n").map((paragraph, index) => (
    <p key={index} className="mb-4">
      {paragraph}
    </p>
  ))

  return (
    <Card className="overflow-hidden">
      <div className="relative w-full h-[300px] bg-muted">
        {isLoadingImage ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          coverImage && (
            <img src={coverImage || "/placeholder.svg"} alt={title} className="w-full h-full object-cover" />
          )
        )}
      </div>
      <CardContent className="p-6">
        <h1 className="text-3xl font-bold mb-6">{title}</h1>
        <div className="prose prose-stone max-w-none">{formattedContent}</div>
      </CardContent>
    </Card>
  )
}
